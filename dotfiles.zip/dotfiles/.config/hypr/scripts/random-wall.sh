#!/usr/bin/bash

DIR=$HOME/walls/
PICS=($(ls ${DIR}))

RANDOMPICS=${PICS[ $RANDOM % ${#PICS[@]} ]}

if [[ $(pidof swaybg) ]]; then
  pkill swaybg
fi

swaybg -i ${DIR}/${RANDOMPICS} -m fill &

