#!/bin/sh
# Give this user privileged input access for dictation tools + xbox controllers to work
sudo usermod -aG input ${USER}