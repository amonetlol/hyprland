#!/bin/sh
sudo pacman -Sy --needed --noconfirm \
    chromium \
    gimp