#!/bin/bash

#theme="$HOME/.config/rofi/network.rasi"
theme="network.rasi"

networkmanager_dmenu -i -p "Network:" \
		  -theme ${theme}